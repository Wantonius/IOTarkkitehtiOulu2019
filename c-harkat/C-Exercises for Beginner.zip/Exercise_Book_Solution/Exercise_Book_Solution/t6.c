//
// T6
//
//

#include <stdio.h>

int main(void)
{
	double pituus=0.0;
	double paino=0.0;
	double indeksi=0.0;

	printf("Anna pituus metrein�: ");
	scanf("%lf",&pituus);
	printf("Anna paino kiloina  : ");
	scanf("%lf",&paino);

	indeksi = paino / (pituus * pituus);

	if (indeksi < 20)
		printf("Voisit sy�d� hieman enemm�n\n");
	if (indeksi >= 20 && indeksi <= 25)
		printf("Olet normaalipainoinen\n");
	if (indeksi >= 25 && indeksi <= 30)
		printf("Pieni liikunnan lis�ys olisi hyv�ksi\n");
	if (indeksi > 30)
		printf("Sinun on teht�v� painollesi jotain radikaalia\n");

	return(0);
}
