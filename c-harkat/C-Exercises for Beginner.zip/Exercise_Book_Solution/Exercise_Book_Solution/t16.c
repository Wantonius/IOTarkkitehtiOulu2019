//
// T16
//
// 

#include <stdio.h>

struct painoindeksi
{
	double pituus;
	double paino;
	double pindeksi;
};

int main(void)
{
	struct painoindeksi indeksi;

	printf("Anna pituus metrein�: ");
	scanf("%lf",&indeksi.pituus);
	printf("Anna paino kiloina  : ");
	scanf("%lf",&indeksi.paino);

	indeksi.pindeksi = indeksi.paino / (indeksi.pituus * indeksi.pituus);

	printf("\nPaino       : %3.2lf\n",indeksi.paino);
	printf("Pituus      : %3.2lf\n",indeksi.pituus);
	printf("Painoindeksi: %3.2lf\n",indeksi.pindeksi);

	if (indeksi.pindeksi < 20)
		printf("Voisit sy�d� hieman enemm�n\n");
	if (indeksi.pindeksi >= 20 && indeksi.pindeksi <= 25)
		printf("Olet normaalipainoinen\n");
	if (indeksi.pindeksi >= 25 && indeksi.pindeksi <= 30)
		printf("Pieni liikunnan lis�ys olisi hyv�ksi\n");
	if (indeksi.pindeksi > 30)
		printf("Sinun on teht�v� painollesi jotain radikaalia\n");

	return(0);
}

