//
// T14
//
// 

#include <stdio.h>
#include <string.h>

#define MAXLEN 1100

int main(void)
{
	char mjono[MAXLEN];
	char merkki;
	int lkm=0;
	int i;

	printf("Anna merkkijono (max 1100 mki) : ");
	fgets(mjono, sizeof(mjono), stdin);
	mjono[strlen(mjono)-1]='\0';  // poistetaan enter -merkki

	printf("Anna haettava merkki: ");
	scanf("%c",&merkki);

	for (i=0;i<strlen(mjono);i++)
		if(mjono[i]==merkki)
			lkm++;

	printf("Haettu merkki %c l�ytyi %d kpl",merkki,lkm);
	return(0);
}

