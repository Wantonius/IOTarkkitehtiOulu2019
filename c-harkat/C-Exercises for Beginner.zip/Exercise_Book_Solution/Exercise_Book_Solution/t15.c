//
//  T15
//
// 

#include <stdio.h>
#include <string.h>

#define MAXLEN 1100

int main(void)
{
	char mjono[MAXLEN];
	int i;

	printf("Anna merkkijono (max 1100 mki) : ");
	fgets(mjono, sizeof(mjono), stdin);
	mjono[strlen(mjono)-1]='\0';  // poistetaan enter -merkki

	for (i=0;i<strlen(mjono);i+=3)
		mjono[i]=mjono[i]+1;
	for (i=2;i<strlen(mjono);i+=3)
		mjono[i]=mjono[i]-1;

	printf("<%s>\n",mjono);
	return(0);
}

