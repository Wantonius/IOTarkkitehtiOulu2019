//
// T19
//
// 

#include <stdio.h>
#include <string.h>

#define MAX 10

typedef struct
{
	char nimi[31];
	double pituus;
	double paino;
	double pindeksi;
} PINDEKSI;

void alusta_indeksi(PINDEKSI []);
void anna_tiedot(PINDEKSI []);
void laske_indeksit(PINDEKSI []);
void tulosta_kaikki(PINDEKSI []);
void nayta_hlo(PINDEKSI []);
void tulosta_huomautus(int);
int  talleta_tiedostoon(PINDEKSI []);
int  lue_tiedostosta(PINDEKSI []);

int main(void)
{
	PINDEKSI indeksi[MAX];
	char valinta[3];

	alusta_indeksi(indeksi);

	while (1)
	{
		memset(valinta,'\0',strlen(valinta));
		printf("Painoindeksi\n");
		printf("1. Tietojen sy�tt�\n");
		printf("2. Indeksin laskenta\n");
		printf("3. Kaikkien tietojen tulostus\n");
		printf("4. Tietojen n�ytt�\n");
		printf("5. Tietojen talletus\n");
		printf("6. Tietojen lukeminen\n");
		printf("L  Lopetus\n");
		printf("Valitse: ");

		scanf("%s",valinta);

		switch (valinta[0])
		{
			case 'L':
			case 'l': return(0);
					  break;
			case '1': anna_tiedot(indeksi);
					  break;
			case '2': laske_indeksit(indeksi);
					  break;
			case '3': tulosta_kaikki(indeksi);
					  break;
			case '4': nayta_hlo(indeksi);
					  break;
			case '5': talleta_tiedostoon(indeksi);
					  break;
			case '6': lue_tiedostosta(indeksi);
					  break;
			default : printf("Virheellinen valinta\n");
			          break;
		}
	}

	return(0);
}

void alusta_indeksi(PINDEKSI indeksi[])
{
	int i;

	for (i=0;i<MAX;i++)
	{
		memset(indeksi[i].nimi, '\0', strlen(indeksi[i].nimi));
		indeksi[i].paino=0.0;
		indeksi[i].pituus=0.0;
		indeksi[i].pindeksi=0.0;
	}
}

void anna_tiedot(PINDEKSI indeksi[])
{
	int i=0;
	char nimi[31];

	for (i=0;i<MAX;i++)
	{
		printf("Anna tiedot painoindeksiin (Loppu) lopettaa\n");
		printf("Anna henkil�n nimi  : ");
		scanf("%s",nimi);
		if (strcmp(nimi,"Loppu") == 0)
			break;

		strcpy(indeksi[i].nimi,nimi);
		printf("Anna pituus metrein�: ");
		scanf("%lf",&indeksi[i].pituus);
		printf("Anna paino kiloina  : ");
		scanf("%lf",&indeksi[i].paino);
	}
}

void laske_indeksit(PINDEKSI indeksi[])
{
	int i;

	for (i=0;i<MAX;i++)
		if (indeksi[i].paino > 0.0)
			indeksi[i].pindeksi = indeksi[i].paino / (indeksi[i].pituus * indeksi[i].pituus);
		else
			break;
	printf("Indeksej� laskettu %d kpl\n",i);
}

void tulosta_kaikki(PINDEKSI indeksi[])
{
	int x;

	for (x=0;x<MAX;x++)
	{
		if (indeksi[x].paino == 0.0)
			break;

		printf("Nimi        : %s\n",indeksi[x].nimi);
		printf("Paino       : %3.2lf\n",indeksi[x].paino);
		printf("Pituus      : %3.2lf\n",indeksi[x].pituus);
		printf("Painoindeksi: %3.2lf\n",indeksi[x].pindeksi);

		tulosta_huomautus(indeksi[x].pindeksi);
	}
}

void nayta_hlo(PINDEKSI indeksi[])
{
	int i,x;
	char nimi[31];

	// tulostetaan valitun henkil�n tiedot
	while (1)
	{
		printf("Kenen tiedot tulostetaan: (Loppu): ");
		scanf("%s",nimi);
		if (strcmp(nimi,"Loppu") == 0)
			break;

		x=-1;
		for (i=0;i<MAX;i++)
			if (strcmp(indeksi[i].nimi,nimi) == 0)
				x=i;

		if (x== -1)
		{
			printf("Henkil�� ei l�ydy (%s)\n",nimi);
			continue;
		}

		printf("Nimi        : %s\n",indeksi[x].nimi);
		printf("Paino       : %3.2lf\n",indeksi[x].paino);
		printf("Pituus      : %3.2lf\n",indeksi[x].pituus);
		printf("Painoindeksi: %3.2lf\n",indeksi[x].pindeksi);

		tulosta_huomautus(indeksi[x].pindeksi);
	}
}

void tulosta_huomautus(int pindeksi)
{
	if (pindeksi < 1)
		printf("Indeksi� ei ole laskettu\n");
	if (pindeksi < 20 && pindeksi > 1)
		printf("Voisit sy�d� hieman enemm�n\n");
	if (pindeksi >= 20 && pindeksi <= 25)
		printf("Olet normaalipainoinen\n");
	if (pindeksi >= 25 && pindeksi <= 30)
		printf("Pieni liikunnan lis�ys olisi hyv�ksi\n");
	if (pindeksi > 30)
		printf("Sinun on teht�v� painollesi jotain radikaalia\n");
}

int talleta_tiedostoon(PINDEKSI indeksi[])
{
	FILE *out;
	int i;
	int talletettu=0;

	if ((out = fopen("pindeksi.dat", "w")) == NULL)
	{
		printf("Tiedoston <pindeksi.dat> avaaminen ep�onnistui\n");
		return(1);
	}

	for (i=0;i<MAX;i++)
	{
		if (indeksi[i].paino > 0.0)
		{
			fprintf(out,"%1.2lf %3.2lf %2.2lf %-30.30s\n",
					indeksi[i].pituus,indeksi[i].paino,
					indeksi[i].pindeksi,indeksi[i].nimi);
			talletettu++;
		}
	}

	printf("Tiedostoon <pindeksi.dat> talletettu %d kpl tietoja\n",
			talletettu);
	fclose(out);

	return(0);
}

int  lue_tiedostosta(PINDEKSI indeksi[])
{
	FILE *in;
	PINDEKSI tietue;
	int i=0;

	if ((in = fopen("pindeksi.dat", "r")) == NULL)
	{
		printf("Tiedoston <pindeksi.dat> avaaminen ep�onnistui\n");
		return(1);
	}

	while(fscanf(in,"%lf %lf %lf %s",&tietue.pituus,
			&tietue.paino,&tietue.pindeksi,tietue.nimi) != EOF)
	{
		strcpy(indeksi[i].nimi, tietue.nimi);
		indeksi[i].pituus=tietue.pituus;
		indeksi[i].paino=tietue.paino;
		indeksi[i].pindeksi=tietue.pindeksi;
		i++;
	}
	printf("Tiedostosta <pindeksi.dat> luettu %d kpl tietoja\n",i);
	fclose(in);

	return(0);
}


