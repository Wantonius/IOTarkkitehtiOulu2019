//
// T9
//
// 
#include <stdio.h>

double potenssi(double,int);

int main(void)
{
	double luku1=0;
	int luku2=0;
	double laskettu=0;

	printf("Anna kaksi lukua, j�lkimm�inen kokonaisluku (max 10)\n");
	printf("esim. 2.0,6)  :  ");
	scanf("%lf,%d", &luku1, &luku2);

	laskettu = potenssi(luku1,luku2);

	if (laskettu == -1)
		printf("Liian suuri l�ht�arvo %d (max 10)\n", luku2);
	else
		printf("Luku %5.2f potenssiin %d = %5.2f\n",luku1,luku2,laskettu);

	return(0);
}

double potenssi(double eka, int toka)
{
	int i;
	double summa=1;

	if (toka > 10)
		return(-1);

	for (i=1;i<toka+1;i++)
		summa*=eka;

	return(summa);
}
