//
// T7
//
// 

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main(void)
{
	int arvottu=0;
	int numero=0;
	int lkm=0;

	/* initialize random seed: */
	srand((unsigned int)time((time_t *)NULL));

	/* generate "random" number */
	arvottu=rand()%100+1;

	printf("Arvaa numero v�lilt� 1..100 : ");
	while (1)
	{

		if (scanf("%d",&numero) != 1)
		{
			printf("Virheellinen sy�te, ohjelma keskeytet��n\n");
			exit(1);
		}
		if (numero < 1 || numero > 100)
		{
			printf("Liian pieni/suuri numero. Anna v�lilt� 1..100 : ");
			numero=0;
			continue;
		}
		lkm++;
		if (numero == arvottu)
		{
			printf("Onneksi olkoon, arvasit oikean numeron %d yrityksen j�lkeen!!!!\n",lkm);
			break;
		}
		if (numero < arvottu)
			printf("\nNumero liian pieni, anna uusi : ");
		if (numero > arvottu)
			printf("\nNumero liian suuri, anna uusi : ");

	}
	return(0);
}
