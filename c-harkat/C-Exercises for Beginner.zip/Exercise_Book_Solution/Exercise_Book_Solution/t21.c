//
// T21
//
// 

#include <stdio.h>
#include <string.h>

int main(void)
{
	char merkkijono[21];
	char mjono[100];

	printf("Anna merkkijono: ");

	fgets(mjono, sizeof(mjono), stdin);
	mjono[strlen(mjono)-1]='\0';  // poistetaan enter -merkki

	if (strlen(mjono) > 20)
		printf("Annettu merkkijono ei mahdu varattuun tilaan\n");
	else
	{
		printf("Hyvin mahtuu\n");
		strncpy(merkkijono, mjono,20);
		//printf("%s\n", merkkijono);
	}

	return(0);
}


