//
// T13
//
// 

#include <stdio.h>
#include <string.h>

#define MAXLEN 11

int main(void)
{
	char mjono[MAXLEN];
	int i;

	printf("Anna merkkijono (max 10 mki) : ");
	fgets(mjono, sizeof(mjono), stdin);
	mjono[strlen(mjono)-1]='\0';  // poistetaan enter -merkki

	for (i=0;i<strlen(mjono);i++)
		printf("%c\n",mjono[i]);

	return(0);
}

