//
// T4
//
// 

#include <stdio.h>

int main(void)
{
	int luku=0;
	int i=0;
	int alku=0, loppu=0;

	printf("Mink� luvun kertotaulun haluat? ");
	scanf("%d", &luku);

	for (i=1; i<11; i++)
		printf("%d * %d = %d\n", i, luku, i * luku);

	// teht�v�n toinen osa
	printf("Mink� alueelta kertotaulun haluat? (mist�,mihin) ");
	scanf("%d,%d",&alku,&loppu);

	// ennen t�t� pit�isi tarkistaa ett� alku < loppu
	// ja mahdollisesti vaihtaa ko. lukujen paikkoja
	for (i=alku; i<loppu+1; i++)
		printf("%d * %d = %d\n", i, luku, i * luku);

	return(0);
}

