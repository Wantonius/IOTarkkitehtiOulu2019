//
// T2
//
// 

#include <stdio.h>

int main(void)
{
	int pituus1=0, pituus2=0, pituus3=0;

	printf("Anna kolmen henkil�n pituus pilkulla eroteltuna: ");
	scanf("%d, %d, %d", &pituus1, &pituus2, &pituus3);

	// printf("%3d %3d %3d\n", pituus1,pituus2,pituus3);
	printf("Keskiarvo = %3d (py�ristettyn� 1 cm tarkkuuteen alasp�in)\n",
			(pituus1+pituus2+pituus3) / 3);

	return(0);
}
