//
// T17
//
// 

#include <stdio.h>

struct painoindeksi
{
	char nimi[31];
	double pituus;
	double paino;
	double pindeksi;
};

int main(void)
{
	struct painoindeksi indeksi[3];
	int i;

	// kysyt��n kolmen henkil�n tiedot
	for (i=0;i<3;i++)
	{
		printf("Anna henkil�n nimi  : ");
		scanf("%s",indeksi[i].nimi);
		printf("Anna pituus metrein�: ");
		scanf("%lf",&indeksi[i].pituus);
		printf("Anna paino kiloina  : ");
		scanf("%lf",&indeksi[i].paino);
	}

	// lasketaan painoindeksit
	for (i=0;i<3;i++)
		indeksi[i].pindeksi = indeksi[i].paino / (indeksi[i].pituus * indeksi[i].pituus);

	// tulostetaan kaikki tiedot
	for (i=0;i<3;i++)
	{
		printf("\n");
		printf("Nimi        : %s\n",indeksi[i].nimi);
		printf("Paino       : %3.2lf\n",indeksi[i].paino);
		printf("Pituus      : %3.2lf\n",indeksi[i].pituus);
		printf("Painoindeksi: %3.2lf\n",indeksi[i].pindeksi);

		if (indeksi[i].pindeksi < 20)
			printf("Voisit sy�d� hieman enemm�n\n");
		if (indeksi[i].pindeksi >= 20 && indeksi[i].pindeksi <= 25)
			printf("Olet normaalipainoinen\n");
		if (indeksi[i].pindeksi >= 25 && indeksi[i].pindeksi <= 30)
			printf("Pieni liikunnan lis�ys olisi hyv�ksi\n");
		if (indeksi[i].pindeksi > 30)
			printf("Sinun on teht�v� painollesi jotain radikaalia\n");
	}

	return(0);
}


