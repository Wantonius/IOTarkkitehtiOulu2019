//
// T8
//
// 

#include <stdio.h>

int suurin(int,int,int);

int main(void)
{
	int a=5;
	int b=7;
	int c=3;

	printf("Suurin luku = %d\n", suurin(a,b,c));

	return(0);
}

int suurin(int eka, int toka, int kolmas)
{
	if (eka > toka && eka > kolmas)
		return(eka);
	else
		if (toka > kolmas)
			return(toka);

	return(kolmas);
}
