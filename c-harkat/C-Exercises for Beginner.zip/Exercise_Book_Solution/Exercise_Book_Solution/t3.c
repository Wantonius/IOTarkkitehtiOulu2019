//
// T3
//
// 

#include <stdio.h>

int main(void)
{
	float litrahinta = 1.47;
	float ostettu = 0.00;
	float maksettu = 0.00;

	printf("Montako litraa ostit: ");
	scanf("%f", &ostettu);
	printf("Paljonko rahaa annoit: ");
	scanf("%f", &maksettu);

	printf("Bensakuitti\n\n");
	printf("Litrahinta on %1.2lf E/litra\n", litrahinta);
	printf("Ostettu m��r� on %3.2lf litraa\n", ostettu);
	printf("Maksettava %3.2lf E\n", ostettu * litrahinta);
	printf("Maksettu %3.2lf E\n", maksettu);
	printf("Takaisin %3.2lf E\n", maksettu - (ostettu * litrahinta));

	return(0);
}
