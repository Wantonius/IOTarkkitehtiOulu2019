//
// T24
//
// 

#include <stdio.h>
#include <string.h>

int main(void)
{
	char postino[6];

	memset(postino,'\0',strlen(postino));

	printf("Anna postinumero: ");
	fgets(postino, sizeof(postino), stdin);

	printf("10%s\n",postino);

	return(0);
}

