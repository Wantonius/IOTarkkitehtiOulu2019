//
// T1
//
// 

#include <stdio.h>

int main(void)
{
	int a = 7;
	int b;
	
	printf("eka=%3d toka=%3d\n", a,b);
	
	b=3;
	printf("eka=%3d toka=%3d\n", a,b);
	printf("summa=%3d erotus=%3d\n", a+b, a-b);
	
	printf("summa=%3c erotus=%3c\n", a+b, a-b);	
	
	return(0);
}