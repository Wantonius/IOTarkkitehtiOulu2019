//
// T10
//
// 

#include <stdio.h>

void jakauma(int,int);

int main(void)
{
	int taulu[10];
	int i = 0;

	//----------------------------------------------------------
	// Teht�v�n osa A, lukujen sy�tt� ja tulostus
	// ---------------------------------------------------------

	printf("Sy�t� 10 arvosanaa (0..5)\n");
	while (i<10)
	{
		printf("Anna arvosana nro %d : ", i+1);
		scanf("%d", &taulu[i]);
		if (taulu[i] < 0 || taulu[i] > 5)
			printf("Arvon pit�� olla v�lilt� 0..5\n");
		else
			i++;
	}

	printf("Arvosanat sy�tt�j�rjestyksess�\n");
	for (i=0;i<10;i++)
		printf("%d\n",taulu[i]);

	printf("\nArvosanat k��nteisess� sy�tt�j�rjestyksess�\n");
	for (i=9;i>-1;i--)
		printf("%d\n", taulu[i]);

	// ---------------------------------------------------------
	// Teht�v�n osa B
	// ---------------------------------------------------------

	// keskiarvon laskenta ja tulostukset

	double summa = 0.0;
	int lkmtaulu[6];

	for (i=0;i<10;i++)
		lkmtaulu[i] = 0;

	for (i=0;i<10;i++)
	{
		summa += taulu[i];
		lkmtaulu[taulu[i]]++;
	}

	printf("\nKeskiarvo: %2.2lf\n", summa / 10);

	for (i=0;i<6;i++)
		jakauma(i,lkmtaulu[i]);

	return(0);
}

void jakauma(int count, int montako)
{
	int i;

	printf("%1.1d:",count);
	for (i=0;i<montako;i++)
		printf("*");
	printf("\n");
}

