//
// T12
//
// 

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define MAX_LKM 20
#define MAX_VALUE 20

void tayta(int [],int kpl,int max);
int summa(int [],int);
void tulosta_taulu(int [],int);
int pienin(int [],int);
int suurin(int [],int);

int main(void)
{
	int table[MAX_LKM];
	int yhteensa=0;

	tayta(table,MAX_LKM,MAX_VALUE);

	// testausta varten, kommentoidaan lopullisessa versiossa
	// tulosta_taulu(table, MAX_LKM);

	yhteensa=summa(table, MAX_LKM);
	printf("Summa    : %d\n",yhteensa);
	printf("Keskiarvo: %2.2lf\n", (double)yhteensa / MAX_LKM);
	printf("Pienin   : %d\n",pienin(table,MAX_LKM));
	printf("Suurin   : %d\n",suurin(table,MAX_LKM));

	return(0);
}

void tayta(int taulu[], int kpl,int max)
{
	int i;

	/* initialize random seed: */
	srand((unsigned int)time((time_t *)NULL));

	for (i=0; i<kpl; i++)
		taulu[i]=rand()%max+1;
}

int summa(int taulu[],int max)
{
	int summa=0;
	int i;

	for (i=0;i<max;i++)
		summa+=taulu[i];

	return(summa);
}

void tulosta_taulu(int taulu[],int max)
{
	int i;

	for (i=0;i<max;i++)
		printf("%2d\n",taulu[i]);
}

int pienin(int taulu[],int max)
{
	int pienin=99;
	int i;

	for (i=0;i<max;i++)
		if (taulu[i] < pienin)
			pienin=taulu[i];

	return(pienin);
}

int suurin(int taulu[],int max)
{
	int suurin=0;
	int i;

	for (i=0;i<max;i++)
		if (taulu[i] > suurin)
			suurin=taulu[i];

	return(suurin);
}


