//
// T11
// 

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define MAX 20

void arpominen(int []);
int laske_summa(int []);
void tulosta_taulu(int []);
int pienin(int []);
int suurin(int []);

int main(void)
{
	int table[MAX];
	int summa=0;

	arpominen(table);

	// testausta varten, kommentoidaan lopullisessa versiossa
	tulosta_taulu(table);

	summa=laske_summa(table);
	printf("Summa    : %d\n",summa);
	printf("Keskiarvo: %2.2lf\n", (double)summa / MAX);
	printf("Pienin   : %d\n",pienin(table));
	printf("Suurin   : %d\n",suurin(table));

	return(0);
}

void arpominen(int taulu[])
{
	int i;

	/* initialize random seed: */
	srand((unsigned int)time((time_t *)NULL));

	for (i=0; i<MAX; i++)
		taulu[i]=rand()%20+1;
}

// testausta varten, ei lopullisessa versiossa
void tulosta_taulu(int taulu[])
{
	int i;

	for (i=0;i<MAX;i++)
		printf("%2d\n",taulu[i]);
}

int laske_summa(int taulu[])
{
	int summa=0;
	int i;

	for (i=0;i<MAX;i++)
		summa+=taulu[i];

	return(summa);
}

int pienin(int taulu[])
{
	int pienin=99;
	int i;

	for (i=0;i<MAX;i++)
		if (taulu[i] < pienin)
			pienin=taulu[i];

	return(pienin);
}

int suurin(int taulu[])
{
	int suurin=0;
	int i;

	for (i=0;i<MAX;i++)
		if (taulu[i] > suurin)
			suurin=taulu[i];

	return(suurin);
}


