//
// T22
//
// 

#include <stdio.h>
#include <string.h>

int main(void)
{
	char etunimi[31];
	char sukunimi[31];

	printf("Anna etunimi : ");
	fgets(etunimi, sizeof(etunimi), stdin);
	etunimi[strlen(etunimi)-1]='\0';  // poistetaan enter -merkki

	printf("Anna sukunimi: ");
	fgets(sukunimi, sizeof(sukunimi), stdin);
	sukunimi[strlen(sukunimi)-1]='\0';  // poistetaan enter -merkki

	printf("%s %s\n", etunimi,sukunimi);

	return(0);
}

