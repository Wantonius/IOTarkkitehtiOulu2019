//
// T5
//
// 

#include <stdio.h>

int main(void)
{
	int luku=0;		// sy�tett�v� kokonaisluku
	int kpl=0;		// montako lukua on sy�tetty
	int summa=0;	// annettujen lukujen summa

	printf("Anna kokonaislukuja, 0 lopettaa\n");

	do
	{
		scanf("%d", &luku);
		summa+=luku;
		kpl++;
	}
	while (luku != 0);
	kpl--;  // luku 0 oli lis�nnyt kappalelaskuria ennen poistumista

	printf("Summa     = %5d\n", summa);
	printf("Keskiarvo = %.2lf\n", (float)summa / kpl);
	printf("Kpl-m��r� = %5d\n", kpl);

	return(0);
}
