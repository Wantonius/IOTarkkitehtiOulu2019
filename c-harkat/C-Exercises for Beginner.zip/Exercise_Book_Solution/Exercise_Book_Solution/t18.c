//
// T18
//
// 

#include <stdio.h>
#include <string.h>

struct painoindeksi
{
	char nimi[31];
	double pituus;
	double paino;
	double pindeksi;
};

int main(void)
{
	struct painoindeksi indeksi[3];
	int i,x;
	char nimi[31];

	// kysyt��n kolmen henkil�n tiedot
	for (i=0;i<3;i++)
	{
		printf("Anna henkil�n nimi  : ");
		scanf("%s",indeksi[i].nimi);
		printf("Anna pituus metrein�: ");
		scanf("%lf",&indeksi[i].pituus);
		printf("Anna paino kiloina  : ");
		scanf("%lf",&indeksi[i].paino);
	}

	// lasketaan painoindeksit
	for (i=0;i<3;i++)
		indeksi[i].pindeksi = indeksi[i].paino / (indeksi[i].pituus * indeksi[i].pituus);

	// tulostetaan valitun henkil�n tiedot
	while (1)
	{
		printf("Kenen tiedot tulostetaan: (Loppu): ");
		scanf("%s",nimi);
		if (strcmp(nimi,"Loppu") == 0)
			break;

		x=-1;
		for (i=0;i<3;i++)
		{
			if (strcmp(indeksi[i].nimi,nimi) == 0)
				x=i;
		}
		if (x== -1)
		{
			printf("Henkil�� ei l�ydy (%s)\n",nimi);
			continue;
		}

		printf("Nimi        : %s\n",indeksi[x].nimi);
		printf("Paino       : %3.2lf\n",indeksi[x].paino);
		printf("Pituus      : %3.2lf\n",indeksi[x].pituus);
		printf("Painoindeksi: %3.2lf\n",indeksi[x].pindeksi);

		if (indeksi[x].pindeksi < 20)
			printf("Voisit sy�d� hieman enemm�n\n");
		if (indeksi[x].pindeksi >= 20 && indeksi[x].pindeksi <= 25)
			printf("Olet normaalipainoinen\n");
		if (indeksi[x].pindeksi >= 25 && indeksi[x].pindeksi <= 30)
			printf("Pieni liikunnan lis�ys olisi hyv�ksi\n");
		if (indeksi[x].pindeksi > 30)
			printf("Sinun on teht�v� painollesi jotain radikaalia\n");
	}

	return(0);
}



