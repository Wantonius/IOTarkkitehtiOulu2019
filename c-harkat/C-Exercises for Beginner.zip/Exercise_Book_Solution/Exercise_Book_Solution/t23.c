//
// T23
//
// 

#include <stdio.h>
#include <string.h>

void tulosta(char [],char [],char [],char,char [],char);

int main(void)
{
	char tunnus[12];

	char pv[3];
	char kk[3];
	char vv[3];
	char erotin;
	char lkm[4];
	char tarkiste;

	memset(pv,'\0',3);
	memset(kk,'\0',3);
	memset(vv,'\0',3);
	memset(lkm,'\0',4);

	printf("Anna henkilotunnus : ");
	fgets(tunnus, sizeof(tunnus), stdin);

	strncpy(pv,tunnus,2);
	strncpy(kk,&tunnus[2],2);
	strncpy(vv,&tunnus[4],2);
	erotin=tunnus[6];
	strncpy(lkm,&tunnus[7],3);
	tarkiste=tunnus[10];

	tulosta(pv,kk,vv,erotin,lkm,tarkiste);

	return(0);
}

void tulosta(char pv[],char kk[],char vv[],char erotin,char lkm[],char tarkiste)
{
	printf("P�iv�     : %s\n",pv);
	printf("Kuukausi  : %s\n",kk);
	printf("Vuosi     : %s\n",vv);
	printf("Erotin    : %c\n",erotin);
	printf("Lukum��r� : %s\n",lkm);
	printf("Tarkiste  : %c\n",tarkiste);
}
