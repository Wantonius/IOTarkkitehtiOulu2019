//
// T15a
//   ohjelma t15 "salaaman" tekstin purku
//
// 

#include <stdio.h>
#include <string.h>

#define MAXLEN 1100

int main(void)
{
	char mjono[MAXLEN];
	int i;

	printf("Anna salattu merkkijono : ");
	fgets(mjono, sizeof(mjono), stdin);
	mjono[strlen(mjono)-1]='\0';  // poistetaan enter -merkki

	for (i=0;i<strlen(mjono);i++)
	{
		if (i%3 == 0)
			printf("%c",mjono[i]-1);
		if (i%3 == 1)
			printf("%c",mjono[i]);
		if (i%3 == 2)
			printf("%c",mjono[i]+1);
	}

	return(0);
}

