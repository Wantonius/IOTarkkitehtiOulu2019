//
// T20
//
// 

#include <stdio.h>

int main(void)
{
	char merkki;
	int merkkeja=0;
	int numeroita=0;

	printf("Anna merkkej�. Lopetus = # \n");
	while (1)
	{
		merkki=getc(stdin);
		if (merkki == '#')
			break;
		merkkeja++;
		if (merkki > 47 && merkki < 58)
			numeroita++;
	}

	// merkkeja -muuttujan arvo jaetaan kahdella koska getc -funktio
	// laskee mukaan my�s ENTER -n�pp�imen
	printf("Merkkej� %d kpl, numeroita %d kpl\n",merkkeja/2,numeroita);

	return(0);
}

