#include <stdio.h>
#include <stdlib.h>
typedef int(*func_ptr)(int,int);

int addFunction(int a, int b);
int minusFunction(int a, int b);
int divideFunction(int a, int b);
int multiplyFunction(int a, int b);
func_ptr choice(int *var1, int *var2);

int main(void) {

	int a=0;
	int b=0;
	int *ptr_a;
	int *ptr_b;
	ptr_a = &a;
	ptr_b = &b;
	int (*calc_ptr)(int,int);
	calc_ptr = choice(ptr_a,ptr_b);
	printf("The result is %d\n", calc_ptr(a,b));
	return 0;
}

int addFunction(int a, int b)
{
	return (a+b);
}

int minusFunction(int a, int b)
{
	return (a-b);
}

int multiplyFunction(int a, int b)
{
	return(a*b);
}

int divideFunction(int a, int b)
{
	return(a/b);
}

func_ptr choice(int *var1, int *var2)
{

	int c = -1;

	printf("\nEnter first number:\n");
	scanf("%d", var1);
	printf("\nEnter second number:\n");
	scanf("%d", var2);
        printf("\nEnter choice: 1) add 2) minus 3) multiply 4) divide\n");
	scanf("%d", &c);
	if (c == 1)
	{
		return &addFunction;
	}
	else if (c == 2)
	{
		return &minusFunction;
	}
	else if (c == 3)
	{
                return &multiplyFunction;
	}
	else if (c == 4)
	{
                return &divideFunction;
	}
	else {
		exit(1);
	}
	return NULL;
}

