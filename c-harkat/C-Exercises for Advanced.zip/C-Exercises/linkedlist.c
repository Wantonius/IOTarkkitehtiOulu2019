/*
 ============================================================================
 Name        : linkedlist.c
 Author      : Sari Prittinen
 Version     :
 Copyright   : Your copyright notice
 Description :
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct opiskelija
{
	char nimi[20];
	int opiskelijanumero;
	char paaaine[20];
	struct opiskelija *next;
	struct opiskelija *prev;
}OPISKELIJA;

typedef struct opiskelija * (*func_ptr) (struct opiskelija *);

struct opiskelija * move_forwards (struct opiskelija *);
struct opiskelija * move_backwards (struct opiskelija *);
struct opiskelija * insert_new (struct opiskelija *);
struct opiskelija * delete (struct opiskelija *);
func_ptr choice();

int main(int argc, char **argv)
{
	struct opiskelija *opiskelija_ptr;

	opiskelija_ptr = malloc(sizeof(OPISKELIJA)); //varataan tilaa yhdelle opiskelijalle


	//annetaan tiedot ekalle opiskelijalle
	strcpy(opiskelija_ptr->nimi, "Sari");
	opiskelija_ptr->opiskelijanumero = 1;
	strcpy (opiskelija_ptr->paaaine , "linux-ohjelmointi");
	opiskelija_ptr->next = NULL;
	opiskelija_ptr->prev = NULL;

	func_ptr action_ptr = NULL;

	do
	{
		/*Choicessa kysytään mitä käyttäjä haluaa tehdä*/
		action_ptr = choice();

		/*Jos käyttäjä valitsi jotain muuta kuin "Lopeta"*/
		if(action_ptr != NULL)
		{
			/*Kutsutaan choicen palauttamaa funktiota*/
			opiskelija_ptr = action_ptr(opiskelija_ptr);

			/*tulostetaan sen opiskelijan tiedot kenen kohdalla ollaan*/
			printf("Nimi: %s\n",opiskelija_ptr->nimi);
			printf("Opiskelijanumero: %d\n",opiskelija_ptr->opiskelijanumero);
			printf("Pääaine: %s\n\n",opiskelija_ptr->paaaine);
		}

	}while(action_ptr!=NULL); //pyöritään tässä kunnes käyttäjä valitsee "Lopeta"

	return 0;
}


/*Menu*/
func_ptr choice()
{
	int c = -1;

	printf("\nEnter choice:\n1) move forwards \n2) move backwards \n3) insert new \n4) delete \n5)Exit\n");
	scanf("%d", &c);

	/*Näytä seuraava*/
	if (c == 1)
	{
		return &move_forwards;
	}

	/*Näytä edellinen*/
	else if (c == 2)
	{
		return &move_backwards;
	}

	/*Lisää uusi*/
	else if (c == 3)
	{
		return &insert_new;
	}

	/*Poista*/
	else if (c == 4)
	{
		return &delete;
	}

	/*Lopeta*/
	else if (c == 5)
	{
		return NULL;
	}

	else
	{
		exit(1);
	}

	return NULL;

}

/*Siirtyy seuraavan opiskelijan kohdalle*/
struct opiskelija* move_forwards(struct opiskelija* student)
{
	/*Jos seuraava opiskelija ei ole NULL, palautetaan seuraava opiskelija*/
	if(student->next != NULL)
	{
		return student -> next;
	}

	/*Muuten pysytään saman opiskelijan kohdalla*/
	else
	{
		return student;
	}
}

/*Siirtyy edellisen opiskelijan kohdalle*/
struct opiskelija* move_backwards(struct opiskelija* student)
{
	/*Jos edellinen opiskelija ei ole NULL, palauttaa edellisen opiskelijan*/
	if(student->prev != NULL)
	{
		return student -> prev;
	}

	/*Muuten pysyy saman opiskelijan kohdalla*/
	else
	{
		return student;
	}
}

/*Lisää uuden opiskelijan*/
struct opiskelija* insert_new(struct opiskelija* student)
{
	/*Luodaan uusi opiskelija ja varataan sille tilaa muistista*/
	struct opiskelija *uusiopiskelija;
	uusiopiskelija = malloc(sizeof(OPISKELIJA));

	/*Kysytään uuden opiskelijan tiedot*/
	printf("Nimi: ");
	scanf("%s", uusiopiskelija->nimi);

	printf("Opiskelijanumero: ");
	scanf("%i", &uusiopiskelija->opiskelijanumero);

	printf("Pääaine:");
	scanf("%s", uusiopiskelija->paaaine);

	/*Uuden opiskelijan 'seuraava' on vastaanotetun opiskelijan 'seuraava'*/
	uusiopiskelija->next = student->next;

	/*uuden opiskelijan 'edellinen' on vastaanotettu opiskelija*/
	uusiopiskelija->prev = student;

	/*vastaanotetun opiskelijan 'seuraava' on uusi opiskelija*/
	student->next = uusiopiskelija;

	/*Jos uuden opiskelijan 'seuraava' ei ole NULL, uuden opiskelijan seuraavan edellinen on uusi opiskelija*/
	if(uusiopiskelija->next != NULL)
	{
		uusiopiskelija->next->prev = uusiopiskelija;
	}

	printf("Uusi opiskelija lisätty\n\n");

	/*Palautetaan uusi opiskelija*/
	return (uusiopiskelija);

}

/*Poistetaan opiskelija*/
struct opiskelija* delete(struct opiskelija* student)
{
	/*Luodaan poistettava opiskelija, johon otetaan talteen poistettavan opiskelijan tiedot*/
	struct opiskelija *poistettavaopiskelija;
	poistettavaopiskelija = student;

	/*Jos on vain yksi opiskelija jäljellä, sitä ei voi poistaa*/
	if(poistettavaopiskelija->prev == NULL && poistettavaopiskelija->next == NULL)
	{
		printf("Et voi poistaa viimeistä opiskelijaa\n\n");
	}

	else
	{
		/*Jos poistettava opiskelija ei ole ketjun ensimmäinen eikä viimeinen*/
		if(poistettavaopiskelija->prev != NULL && poistettavaopiskelija->next != NULL)
		{
			/*Siirretään poistettavan opiskelijan tilalle sitä seuraava opiskelija*/
			student = student->next;

			/*Tilalle siirretyn opiskelijan 'seuraava' on poistettavan opiskelijan 'seuraava'*/
			student->prev = poistettavaopiskelija->prev;

			/*Tilalle siirretyn opiskelijan edellisen seuraava on tilalle siirretty opiskelija*/
			student->prev->next = student;
		}

		/*Jos poistettava opiskelija on ketjun ensimmäinen*/
		if(poistettavaopiskelija->prev == NULL)
		{
			/*Siirretään poistettavan opiskelijan tilalle sitä seuraava opiskelija*/
			student = student->next;

			/*Tilalle siirretyn opiskelijan 'edellinen' on NULL*/
			student->prev = NULL;
		}

		/*Jos poistettava opiskelija on ketjun viimeinen*/
		if(poistettavaopiskelija->next == NULL)
		{
			/*Laitetaan poistettavan opiskelijan tilalle sitä edellinen opiskelija*/
			student = student->prev;

			/*Siirretyn opiskelijan 'seuraava' on NULL*/
			student->next = NULL;
		}

		/*Vapautetaan poistetun opiskelijan varaama muisti*/
		if(poistettavaopiskelija)
		{
			free(poistettavaopiskelija);
		}

		printf("Opiskelija poistettu\n\n");

		/*Palautetaan poistettua opiskelijaa edeltävä tai seuraava opiskelija*/
		return student;
	}

	return 0;
}
