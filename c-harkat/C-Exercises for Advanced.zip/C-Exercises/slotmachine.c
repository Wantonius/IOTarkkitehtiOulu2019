/*
 ============================================================================
 Name        : slotmachine.c
 Author      : Sari Prittinen
 Version     :
 Copyright   : Your copyright notice
 Description :Hedelmäpeliautomaatti
 ============================================================================
 */
/*Peli on suunniteltu niin, että sitä on kätevintä pelata numeronäppäimistöllä*/

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define TRUE 1
#define FALSE 0

//aliohjelmien esittelyt
void taytaKela(char *);
int arvoKuvio();
int tarkistaTulos(char *);

//pääohjelma
int main(int argc, char **argv) {

	//kolme kelaa joihin mahtuu 21 kuviota
	char kela1[21];
	char kela2[21];
	char kela3[21];

	char arvotutKuviot[3]; //taulukko, jossa on kolme tällä hetkellä näkyvillä olevaa kuviota
	int arvottuKuvio=0; //apumuuttuja kuvion arpomista varten
	int lukitut[3] = {FALSE,FALSE,FALSE}; //taulukko, jonka alkiossa on FALSE tarkoittaa ei-lukittua ja TRUE tarkoittaa lukittua
	int lukitus = FALSE; //muuttuja on FALSE jos pelaaja ei saa lukita, ja TRUE jos saa lukita

	int i = 0; //muuttuja laskuria varten
	int valinta = 0; //muuttuja, joka sisältää pelaajan syöttämän valinnan
	int ekaKerta = TRUE; //muuttuja kertoo, onko ensimmäinen pelikerta, jolloin kone ei vielä anna voittoa alkutilanteessa

	int rahat = 50; //pelaajan rahamäärä
	int panos = 1; //pelipanos
	int pyorayta = TRUE; //pyöräytetäänkö keloja
	int tulos = 0; //voittokerroin

	//alustukset satunnaislukuja varten
	time_t siemen;
	time(&siemen);
	srand(siemen);

	//arvotaan jokaiseen kelaan kuviot satunnaiseen järjestykseen
	taytaKela(kela1);
	taytaKela(kela2);
	taytaKela(kela3);

	do
	{
		printf("Hedelmäpeli\t");

		//panosta lasketaan automaattisesti, jos se on suurempi kuin rahamäärä
		if(rahat<panos)
		{
			panos = rahat;
		}

		//Jos pelaaja haluaa pyöräyttää keloja
		if(pyorayta == TRUE)
		{
			for(i = 0; i < 3 ; i++)
			{
				/*arvotaan numero 0-20. Tämän voisi arpoa jokaiselle kelalle erikseenkin,
				 * mutta riittänee kun kelojen sisällöt on jo arvottu eri järjestyksiin*/
				arvottuKuvio = arvoKuvio();

				//jos kuviota ei ole lukittu, sen tilalle uusi kuvio
				if(i==0 && lukitut[i]==FALSE)
				{
					arvotutKuviot[i] = kela1[arvottuKuvio];
				}

				else if(i==1 && lukitut[i]==FALSE)
				{
					arvotutKuviot[i] = kela2[arvottuKuvio];
				}

				else if(i==2 && lukitut[i]==FALSE)
				{
					arvotutKuviot[i] = kela3[arvottuKuvio];
				}
			}

			//tarkistetaan tuliko voittoa (ei alkutilanteessa)
			if(!ekaKerta)
			{
				tulos = tarkistaTulos(arvotutKuviot);
			}

			//jos tuli voitto, lisätään rahasummaa ja estetään lukitus
			if(tulos>0)
			{
				rahat = rahat + (tulos*panos);
				lukitus = FALSE;
			}

			//laitetaan lukitukset ja "pyöräytys" pois päältä
			lukitut[0] = FALSE;
			lukitut[1] = FALSE;
			lukitut[2] = FALSE;
			pyorayta = FALSE;
		}

		//tulostetaan tietoja
		printf("Rahat: %d\t", rahat);
		printf("Panos: %d\n\n", panos);
		printf("\t\t");

		//tulostetaan kuviot
		for(i = 0; i < 3 ; i++)
		{
			printf("%c\t", arvotutKuviot[i]);
		}

		printf("\n\t");

		//tulostetaan tieto voitosta
		if(tulos>0)
		{
			printf("\tVOITTO %dx\tVOITTO %dx", tulos, tulos);
		}

		//tulostetaan *-merkki niiden kuvioiden alle jotka on lukittu ja ohjeet lukitsemista varten
		if(lukitus == TRUE)
		{
			printf("\t");
			if(lukitut[0]==TRUE)
			{
				printf("*");
			}

			printf("\t");
			if(lukitut[1]==TRUE)
			{
				printf("*");
			}

			if(lukitut[2]==TRUE)
			{
				printf("\t*");
			}

			printf("\nLukitse:\t");
			printf("1\t2\t3"); //kelat voi lukita napeilla 1, 2 ja 3
		}
		else
		{
			printf("\t");
		}

		//tulostetaan ohjeet pelaamista varten
		if(rahat > 0)
		{
			printf("\n\nPelaa: 0\t");
			printf("Nosta panosta: 4 Laske panosta: 6 Lopeta peli: 8\n");
			scanf("%d", &valinta);
		}
		//jos ei ole rahaa tai rahaa on liikaa tulostetaan jotain muuta ja lopetaan peli
		else
		{
			if(rahat < 0) //jos on niin paljon rahaa että int ei riitä, rahat menee miinukselle
			{
				printf("\nPeliautomaatista loppui rahat.\n");
			}
			if(rahat == 0)
			{
				printf("\n\tRahasi loppuivat.\n");
			}
			printf("\n\n GAME OVER\tGAME OVER\tGAME OVER");
			valinta = 8;
		}

		if(valinta == 0) //valinta "pelaa"
		{
			//jos tällä kierroksella on lukittu, lukitus estetään seuraavalta kierrokselta
			if(lukitut[0] == TRUE || lukitut[1] == TRUE || lukitut[2] == TRUE)
			{
				lukitus = FALSE;
			}
			else
			{
				lukitus = TRUE;
			}

			//laitetaan pyöräytys päälle, vähennetään rahoja
			pyorayta = TRUE;
			rahat = rahat - panos;
			ekaKerta = FALSE;
		}

		else if(valinta == 4) //valinta nosta panosta
		{
			if(panos<rahat) //panosta voi nostaa niin korkeaksi kuin on rahaa
			{
				panos++;
			}
			else //jos yrittää nostaa panosta korkeammaksi kuin rahamäärää, se palautuu ykköseen
			{
				panos = 1;
			}

			//Jos nostaa panosta, ei saa lukita
			lukitus = FALSE;
			lukitut[0] = FALSE;
			lukitut[1] = FALSE;
			lukitut[2] = FALSE;
		}

		else if(valinta == 6) //valinta laske panosta
		{
			if(panos > 1)
			{
				panos--;
			}
		}

		if(lukitus == TRUE)//seuraavat valinnat voi tehdä jos lukitus on sallittu
		{
			if(valinta == 1) //valinta lukitse eka kuvio
			{
				if(lukitut[0]==FALSE)
				{
					lukitut[0]=TRUE;
				}
				else
				{
					lukitut[0]=FALSE;
				}
			}

			else if(valinta == 2)//valinta lukitse toka kuvio
			{
				if(lukitut[1]==FALSE)
				{
					lukitut[1]=TRUE;
				}
				else
				{
					lukitut[1]=FALSE;
				}
			}

			else if(valinta == 3)//valinta lukitse kolmas kuvio
			{
				if(lukitut[2]==FALSE)
				{
					lukitut[2]=TRUE;
				}
				else
				{
					lukitut[2]=FALSE;
				}
			}
		}

		if(lukitus == FALSE && (valinta == 1 || valinta == 2 || valinta == 3))
		{
			printf("\nEt voi lukita!!!\n");
		}

		//Tällä tyhjennetään ruutu, mutta ei toimi eclipsessä
		//system("clear");

	}while (valinta != 8);

	if(rahat >= 0 && rahat < 50) //mennään tähän jos rahaa jäi vähemmän kuin alussa oli
	{
		printf("\nSinulle jäi %d euroa.\n", rahat);
	}
	else if(rahat > 50) //mennään tähän jos jäätiin voitolle
	{
		printf("\nVoitit 50 + %d euroa.\n", rahat-50);
	}
	else //tämä tulostetaan jos rahaa tuli niin paljon että int ei riittänyt
	{
		printf("Voitit liikaa rahaa.\n");
	}

	return 0;
}

//arpoo kelan sisälle kuviot satunnaiseen järjestykseen
void taytaKela(char kela[])
{
	int i = 0;
	/*taulukossa on kaikki kuviot mitä aiotaan käyttää*/
	char arvottavatKuviot[21] = {'A','A','B','B','B','C','C','C','C','D','D','D','D','D','E','E','E','E','E','E','J'};
	int kuvionNumero = 0;

		for(i=0;i<21;i++)
		{
			do
			{
				kuvionNumero = arvoKuvio(); //arvotaan numero 0-20
				//tarkistetaan onko kyseisessä alkiossa olevaa kuviota vielä käytetty
				if(arvottavatKuviot[kuvionNumero] != 'F')
				{
					kela[i] = arvottavatKuviot[kuvionNumero]; //asetetaan kuvio kelaan
				}
			//tämä silmukka pyörii niin kauan kunnes löytyy käyttämätön kuvio
			}while(arvottavatKuviot[kuvionNumero] == 'F');

			//käytetyn kuvion tilalle laitetaan "kuvio" F
			arvottavatKuviot[kuvionNumero] = 'F';
		}

}

//arpoo numeron 0-20
int arvoKuvio()
{
	return rand() % 21;
}

//tarkistaa tuliko voittoa ja palauttaa voittokertoimen
int tarkistaTulos(char arvotutKuviot[])
{
	if((arvotutKuviot[0] == 'A' || arvotutKuviot[0] == 'J') &&
			(arvotutKuviot[1] == 'A' || arvotutKuviot[1] == 'J') &&
			(arvotutKuviot[2] == 'A' || arvotutKuviot[2] == 'J'))
	{
		return 50;
	}

	else if((arvotutKuviot[0] == 'B' || arvotutKuviot[0] == 'J') &&
			(arvotutKuviot[1] == 'B' || arvotutKuviot[1] == 'J') &&
			(arvotutKuviot[2] == 'B' || arvotutKuviot[2] == 'J'))
	{
		return 30;
	}

	else if((arvotutKuviot[0] == 'C' || arvotutKuviot[0] == 'J') &&
			(arvotutKuviot[1] == 'C' || arvotutKuviot[1] == 'J') &&
			(arvotutKuviot[2] == 'C' || arvotutKuviot[2] == 'J'))
	{
		return 10;
	}

	else if((arvotutKuviot[0] == 'D' || arvotutKuviot[0] == 'J') &&
			(arvotutKuviot[1] == 'D' || arvotutKuviot[1] == 'J') &&
			(arvotutKuviot[2] == 'D' || arvotutKuviot[2] == 'J'))
	{
		return 10;
	}

	else if((arvotutKuviot[0] == 'A' || arvotutKuviot[0] == 'J') &&
			(arvotutKuviot[1] == 'A' || arvotutKuviot[1] == 'J'))
	{
		return 6;
	}

	else if((arvotutKuviot[0] == 'E' || arvotutKuviot[0] == 'J') &&
			(arvotutKuviot[1] == 'E' || arvotutKuviot[1] == 'J') &&
			(arvotutKuviot[2] == 'E' || arvotutKuviot[2] == 'J'))
	{
		return 3;
	}

	else if(arvotutKuviot[0] == 'A' || arvotutKuviot[0] == 'J')
	{
		return 2;
	}

	else
	{
		return 0;
	}
}
