/*
 ============================================================================
 Name        : lotto.c
 Author      : Sari Prittinen
 Version     :
 Copyright   : Your copyright notice
 Description : Lottokone
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int arvo_numero(int *, int *, int *, int *);

int main(int argc, char **argv)
{
	int oikeat_numerot[7] = {0,0,0,0,0,0,0}; //arvotut lottonumerot
	int lisanumerot[3] = {0,0,0};	//arvotut lisänumerot
	int arvotut_numerot = 0; //montako numeroa on arvottu
	int arvotut_lisanumerot = 0; //montako lisänumeroa on arvottu
	int veikatut_numerot[7] = {0,0,0,0,0,0,0}; //käyttäjän veikkaamat lottonumerot
	int veikattu_numero = 0; //pelaajan syöttämä numero
	time_t siemen;	//siemenluku satunnaisluvun arpomista varten
	int i;
	int k;
	int numero_hyvaksytty = 1; //apumuuttuja tarkistukseen, onko sama numero syötetty jo
	int osuma = 0; //Montako numeroa meni oikein
	int lisanumero_osuma = 0; //Montako lisänumeroa meni oikein

	time(&siemen);
	srand(siemen);	//alustetaan satunnaislukugeneraattori

	printf("Hyvää iltaa!\nTämä on loton virallinen arvonta.\n");
	printf("Veikkaa 7 numeroa väliltä 1-39.\n");

	for(i=0;i<7;i++) //kysytään pelaajalta 7 numeroa ja tallennetaan ne taulukkoon
	{

		do
		{
			numero_hyvaksytty = 1;
			printf("Syötä %d. numero: ", i+1);
			scanf("%d", &veikattu_numero);
			for(k = 0; k < i; k++)
			{
				if(veikattu_numero == veikatut_numerot[k]) //jos sama numero on jo annettu niin kysytään uudelleen
				{
					printf("Olet ja veikannut tämän numeron.\n");
					numero_hyvaksytty = 0;
				}
			}

			if(veikattu_numero < 1 || veikattu_numero > 39) //jos numero on liian iso tai pieni kysytään uudelleen
			{
				printf("Syöttämäsi numero oli liian pieni tai iso.\n");
				numero_hyvaksytty = 0;
			}

			veikatut_numerot[i] = veikattu_numero;

		}while(numero_hyvaksytty == 0);
	}

	for(i=0;i<7;i++) //arvotaan 7 lottonumeroa taulukkoon
	{
		if(i<7)
		{
			oikeat_numerot[i] = arvo_numero(&arvotut_numerot, &arvotut_lisanumerot, oikeat_numerot, lisanumerot);

                }
                arvotut_numerot++;
	}
	for(i=0;i<3;i++) //arvotaan 3 lisänumeroa taulukkoon
	{
		lisanumerot[i] = arvo_numero(&arvotut_numerot, &arvotut_lisanumerot, oikeat_numerot, lisanumerot);
		//lisanumerot[i] = arvo_numero(oikeat_numerot, lisanumerot);
		arvotut_lisanumerot++;
	}


	printf("Arvotaan %d numeroa ja %d lisänumeroa.\n", arvotut_numerot, arvotut_lisanumerot);
	printf("Oikea lottorivi on: ");
	for(i=0;i<7;i++) //tulostetaan oikeat numerot
	{
		printf("%d, ",oikeat_numerot[i]);
	}
	printf("\nJa lisänumerot: ");
	for(i=0;i<3;i++) //tulostetaan lisänumerot
	{
		printf("%d, ",lisanumerot[i]);
	}

	for(i=0; i < 7; i++) //katsotaan montako numeroa meni oikein
	{
		for(k=0; k < 7; k++)
		{
			if(veikatut_numerot[i] == oikeat_numerot[k])
			{
				osuma++;
			}
		}
	}
	printf("\nSait oikein %d numeroa.", osuma );

	if(osuma == 6) //jos meni 6 numeroa oikein, katsotaan menikö lisänumeroita oikein
	{
		for(i=0; i < 7; i++)
		{
			for(k=0; k < 3; k++)
			{
				if(veikatut_numerot[i] == lisanumerot[k])
				{
					lisanumero_osuma++;
				}
			}
		}
		printf(" ja %d lisanumeroa\n", lisanumero_osuma );
	}
	else
	{
		printf("\n");
	}

	if(osuma > 3) //tulostetaan voittiko pelaaja vai ei
	{
		printf("Voitit rahaa." );
	}
	else
	{
		printf("Et voittanut mitään.\nHyvää illanjatkoa." );
	}


	return 0;

}

/*funktio, joka arpoo numeron väliltä 1-39*/
int arvo_numero(int *arvottujen_numeroiden_maara, int *arvottujen_lisanumeroiden_maara, int arvotut_taulukko[], int arvotut_lisanumerot_taulukko[])
//int arvo_numero(int arvotut_taulukko[7], int arvotut_lisanumerot_taulukko[3])
{
	int arvottu_numero; //numero, joka arvotaan
	int i;

	arvottu_numero = rand() % 39 + 1; //arvotaan numero

	/*jos lisänumeroita ei ole vielä arvottu, tarkistetaan vain lottonumerotaulukosta
	 onko arvottua numeroa siellä*/
	if(arvottujen_lisanumeroiden_maara == 0)
	{
		for(i=0; i < *arvottujen_numeroiden_maara; i++)
		{
			if(arvottu_numero == arvotut_taulukko[i])
			{
				arvottu_numero = arvo_numero(&*arvottujen_numeroiden_maara, &*arvottujen_lisanumeroiden_maara, arvotut_taulukko, arvotut_lisanumerot_taulukko);
			}
		}
		return arvottu_numero; //palautetaan arvottu numero
	}
	/*muuten tarkistetaan lottonumerotaulukosta ja lisänumerotaulukosta onko arvottua numeroa niissä*/
	else
	{

		for(i=0; i < *arvottujen_numeroiden_maara; i++)
		//for(i=0; i < 7; i++)
		{
			if(arvottu_numero == arvotut_taulukko[i])
			{
				arvottu_numero = arvo_numero(&*arvottujen_numeroiden_maara, &*arvottujen_lisanumeroiden_maara, arvotut_taulukko, arvotut_lisanumerot_taulukko);
				//arvottu_numero = arvo_numero(arvotut_taulukko, arvotut_lisanumerot_taulukko);
			}
		}
		for(i=0; i < *arvottujen_lisanumeroiden_maara; i++)
		//for(i=0; i < 3; i++)
		{
			if(arvottu_numero == arvotut_lisanumerot_taulukko[i])
			{
				arvottu_numero = arvo_numero(&*arvottujen_numeroiden_maara, &*arvottujen_lisanumeroiden_maara, arvotut_taulukko, arvotut_lisanumerot_taulukko);
				//arvottu_numero = arvo_numero(arvotut_taulukko, arvotut_lisanumerot_taulukko);
			}
		}
		return arvottu_numero; //palautetaan arvottu numero
	}
}
