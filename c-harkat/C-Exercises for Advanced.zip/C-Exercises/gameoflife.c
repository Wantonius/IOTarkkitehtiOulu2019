/*
 ============================================================================
 Name        : gameoflife.c
 Author      : Sari Prittinen
 Version     :
 Copyright   : Your copyright notice
 Description :
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define MAXSIZE 22
#define TRUE 1
#define FALSE 0

typedef struct grid
{
	int alive; //kuollut = 0, elävä = 1
	int no_of_neighbours; //naapureiden määrä
}GRID;

int drawGrid(GRID gridi[][MAXSIZE]);
int copy(GRID gridi[][MAXSIZE]);
int countNeighbours(GRID gridi[][MAXSIZE]);
int rules(GRID gridi[][MAXSIZE]);
char printMenu(int);
int countLivingMembers(GRID gridi[][MAXSIZE]);
int save(int, int , int );

int main(int argc, char **argv)
{
	GRID gridi[22][22]; //taulukko gridmembereille

	//Apumuuttujia for-silmukoiden pyörittelyyn
	int i = 0;
	int j = 0;

	//Näihin otetaan talteen käyttäjän syöttämät koordinaatit
	int x = 0;
	int y = 0;

	int round = 0; //kierrosten määrä
	char selection = 'a'; //valinta, jonka käyttäjä syöttää menussa
	int livingMembersStart = 0; //elävien määrä alussa
	int livingMembersEnd = 0; //elävien määrä lopussa

	//Alustetaan kaikki memberit kuolleiksi ja ei naapureita
	for(i = 0 ; i < MAXSIZE ; i++)
	{
		for(j = 0 ; j < MAXSIZE ; j++)
		{
			gridi[i][j].alive = FALSE;
			gridi[i][j].no_of_neighbours = 0;
		}
	}

	do
	{
		printf("The Game of life. \tRound %d\n\n", round);
		selection = printMenu(round); //tulostetaan menu


		//Valinta syötä living membereitä
		if(selection == 's')
		{

			//pyydetään syöttämään koordinaatit
			printf("Set x-coordinate(1-20):\n");
			scanf("%d", &x);

			printf("Set y-coordinate(1-20):\n");
			scanf("%d", &y);

			//asetetaan gridmember eläväksi
			gridi[x][y].alive = TRUE;

			//tyhjennetään ruutu
			system("clear");

			//tulostetaan gridi
			drawGrid(gridi);


			getchar();
		}

		//Valinta pelaa peliä
		else if(selection == 'g')
		{

			//ensimmäisellä kerralla lasketaan montako livingmemberiä käyttäjä on asettanut
			if(round == 0)
			{
				livingMembersStart = countLivingMembers(gridi);
			}

			//pyöritetään 50 kierrosta eteenpäin
			for(i = 0 ; i < 50 ; i++)
			{
				copy(gridi); //kopio gridin reunat
				countNeighbours(gridi); //laskee naapurit
				rules(gridi); //asettaa elävät/kuolleet
				round++; //kasvatetaan kierrosten määrää
			}

			system("clear"); //tyhjennetään ruutu
			drawGrid(gridi); //tulostetaan gridi
			printf("\n");
			getchar();

		}

		//Valinta lopeta peli
		else if(selection == 'q')
		{
			//tulostetaan kierrokset, elävien määrä alussa ja lopussa
			printf("\nRounds played: %d", round);
			livingMembersEnd = countLivingMembers(gridi); //lasketaan elävien määrä lopussa
			printf("\nLiving members at start: %d", livingMembersStart);
			printf("\nLiving members at end: %d\n", livingMembersEnd);

			//tallennetaan tiedot tiedostoon
			save(round, livingMembersStart, livingMembersEnd);

		}

	//pyörii tässä kunnes käyttäjä syöttää 'q'
	}while(selection!='q');

	return 0;
}

//Tulostaa menun
char printMenu(int round)
{
	char selection = 'a'; //käyttäjän syöttämä valinta

	//Tulostetaan tämän näköinen menu jos ei ole pelattu yhtään kierrosta
	if(round == 0)
	{
		printf("(s)et initial conditions.\n");
		printf("start (g)ame.\n");
		printf("(q)uit game.\n");
	}

	//Muuten menussa on 2  vaihtoehtoa
	else
	{
		printf("continue (g)ame.\n");
		printf("(q)uit game.\n");
	}

	//otetaan talteen käyttäjän syöttämä valinta
	scanf("%c", &selection);

	//palautetaan käyttäjän syöttämä valinta
	return selection;
}

//Tulostaa gridin
int drawGrid(GRID gridi[][MAXSIZE])
{
	int i = 0;
	int j = 0;


	//käydään läpi jokainen gridmember 1-20
	for(i = 1 ; i < MAXSIZE-1 ; i++)
	{
		for(j = 1 ; j < MAXSIZE-1 ; j++)
		{
			//Jos gridmember on elävä tulostetaan x
			if( gridi[i][j].alive == TRUE)
			{
				printf("x ");
			}

			//Jos gridmember on kuollut tulostetaan -
			else
			{
				printf("- ");
			}
		}

		printf("\n");
	}

	return 0;
}

//Kopioi reunimmaiset gridmemberit toiselle reunalle
int copy(GRID gridi[][MAXSIZE])
{
	int i = 0;
	int j = 0;

	//ylä- ja alapystyrivit
	for(i = 1 ; i < MAXSIZE-1 ; i++)
	{
		gridi[i][0] = gridi[i][20];
		gridi[i][21] = gridi[i][1];
	}

	//ylä- ja alavaakarivit
	for(j = 1 ; j < MAXSIZE-1 ; j++)
	{
		gridi[0][j] = gridi[20][j];
		gridi[21][j] = gridi[1][j];
	}

	//nurkat
	gridi[21][21] = gridi[1][1];
	gridi[0][0] = gridi[20][20];
	gridi[0][21] = gridi[20][1];
	gridi[21][0] = gridi[1][20];

	return 0;
}


//laskee naapurit
int countNeighbours(GRID gridi[][MAXSIZE])
{
	int i = 0;
	int j = 0;

	for(i = 1 ; i < MAXSIZE-1 ; i++)
	{
		for(j = 1 ; j < MAXSIZE-1 ; j++)
		{
			gridi[i][j].no_of_neighbours = 0; //asetaan naapureiden määrä nollaksi

			//käydään läpi kaikki viereiset naapurit ja kasvatetaan naapureiden määrää jos naapuri on elossa
			if(gridi[i-1][j-1].alive == TRUE)
			{
				gridi[i][j].no_of_neighbours++;
			}

			if(gridi[i-1][j].alive == TRUE)
			{
				gridi[i][j].no_of_neighbours++;
			}

			if(gridi[i-1][j+1].alive == TRUE)
			{
				gridi[i][j].no_of_neighbours++;
			}

			if(gridi[i][j+1].alive == TRUE)
			{
				gridi[i][j].no_of_neighbours++;
			}

			if(gridi[i+1][j+1].alive == TRUE)
			{
				gridi[i][j].no_of_neighbours++;
			}

			if(gridi[i+1][j].alive == TRUE)
			{
				gridi[i][j].no_of_neighbours++;
			}

			if(gridi[i+1][j-1].alive == TRUE)
			{
				gridi[i][j].no_of_neighbours++;
			}

			if(gridi[i][j-1].alive == TRUE)
			{
				gridi[i][j].no_of_neighbours++;
			}
		}
	}

	return 0;
}


//tarkistetaan ketkä on elossa ja ketkä ei
int rules(GRID gridi[][MAXSIZE])
{
	int i = 0;
	int j = 0;

	for(i = 1 ; i < MAXSIZE-1 ; i++)
	{
		for(j = 1 ; j < MAXSIZE-1 ; j++)
		{
			//Jos gridmember elää ja sillä on 0 tai 1 naapuria, se kuolee
			if(gridi[i][j].alive == TRUE && gridi[i][j].no_of_neighbours < 2)
			{
				gridi[i][j].alive = FALSE;
			}

			//Jos gridmember elää ja sillä on 2 tai 3 naapuria se pysyy elossa
			else if (gridi[i][j].alive == TRUE && gridi[i][j].no_of_neighbours > 1 && gridi[i][j].no_of_neighbours < 4)
			{
				gridi[i][j].alive = TRUE;
			}

			//Jos gridmember elää ja sillä on yli 3 naapuria se kuolee
			else if (gridi[i][j].alive == TRUE && gridi[i][j].no_of_neighbours > 3)
			{
				gridi[i][j].alive = FALSE;
			}

			//Jos gridmember on kuollut ja sillä on 3 naapuria se herää henkiin
			else if(gridi[i][j].alive == FALSE && gridi[i][j].no_of_neighbours == 3)
			{
				gridi[i][j].alive = TRUE;
			}
		}
	}

	return 0;
}

//laskee elävät gridmemberit
int countLivingMembers(GRID gridi[][MAXSIZE])
{
	int i = 0;
	int j = 0;
	int livingMembers = 0;

	for(i = 1 ; i < MAXSIZE-1 ; i++)
	{
		for(j = 1 ; j < MAXSIZE-1 ; j++)
		{
			//jos gridmember on elossa, kasvatetaan lukumäärää
			if(gridi[i][j].alive == TRUE)
			{
				livingMembers++;
			}
		}
	}

	//palautetaan elävien määrä
	return livingMembers;
}

//tallentaa tiedostoon pelitietoja
int save(int round, int livingMembersStart, int livingMembersEnd)
{
	FILE *file; 		//tiedosto
	time_t gameTime;	//aika
	struct tm *aika;	//päivämäärätietue

	//avataan tiedosto, "a" kirjoittaa tiedoston loppuun
	file = fopen("gameoflife.txt","a");

	//Jos avaus ei onnistu, ohjelma lopetetaan
	if (file == NULL) {
	    printf ("Cannot open file to write!\n");
	    exit(-1);
	}

	//tallennetaan kierrosten ja elävien määrät
	fprintf (file, "Rounds played: %d\n", round);
	fprintf (file, "Living members at start: %d\n", livingMembersStart);
	fprintf (file, "Living members at end: %d\n", livingMembersEnd);


	time(&gameTime); //haetaan päivämäärä
    aika = localtime(&gameTime); // muutetaan päivämäärä järkevään muotoon

    //tallennetaan päivämäärä ja kellonaika
    fprintf(file, "Game was played %i.%i.%i %i:%i:%i\n\n",
    		aika->tm_mday,
    		aika->tm_mon + 1,
    		1900 + aika->tm_year,
    		aika->tm_hour,
    		aika->tm_min,
    		aika->tm_sec);

	fclose (file); //suljetaan tiedosto

	return 0;
}
