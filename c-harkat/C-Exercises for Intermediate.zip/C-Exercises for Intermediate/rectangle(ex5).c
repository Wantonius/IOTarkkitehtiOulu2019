#include <stdio.h>

int main (int argc, void **argv)
{
	int i, j, korkeus, leveys;
	
	printf("Korkeus: ");
	scanf("%d", &korkeus);

	printf("Leveys: ");
	scanf("%d", &leveys);

	for(i=1; i<=korkeus; i++)
	{
		for(j=1; j<=leveys; j++)
		{
			printf("*");
		}
		printf("\n");
	}

}
