#include <stdio.h>

int main (int argc, void **argv)
{
	printf("Hello!");
	return 0;
}
