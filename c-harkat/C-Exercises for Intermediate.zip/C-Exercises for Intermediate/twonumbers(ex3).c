#include <stdio.h>

int main (int argc, char **argv)
{
	int luku1, luku2, tulos;
	printf("Anna luku: ");
	scanf("%d", &luku1);
	printf("Anna toinen luku: ");
	scanf("%d", &luku2);
	tulos = luku1 + luku2;
	printf("%d + %d = %d\n", luku1, luku2, tulos);
	return 0;
}
