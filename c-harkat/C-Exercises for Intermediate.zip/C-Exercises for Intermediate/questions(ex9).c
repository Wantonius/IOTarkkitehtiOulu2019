/*
 ============================================================================
 Name        : Exercise5.c
 Author      : Sari Prittinen
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

void ask(char[15]);

int main(void) {

	char name[15];
	time_t siemen;	//seed number for random
	char answer[50];

	time(&siemen);
	srand(siemen); //initialize random number generator

	//asking users name
	printf("What is your name?");
	scanf("%s",&name);

	printf("I will ask questions until you enter \"bye\".\n");

	//asking questions until user answers "bye"
	while(strcmp("bye", answer) != 0)
	{
		ask(name);
		scanf("%s", answer);
	}
	printf("Bye.");
	return 0;
}

void ask(char name[15])
{
	//random number 0-4
	int random_number = rand() % 5;

	//printing the question
	switch(random_number)
	{
	case 0:
		printf("%s, What is your favorite color?", name);
		break;
	case 1:
		printf("%s, What is your favorite food?", name);
		break;
	case 2:
		printf("%s, What is your favorite animal?", name);
		break;
	case 3:
		printf("%s, What is your favorite programming language?", name);
		break;
	case 4:
		printf("%s, What is your favorite month?", name);
		break;
	}
}
