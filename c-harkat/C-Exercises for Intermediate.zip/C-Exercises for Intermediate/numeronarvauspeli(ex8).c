#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#include <conio.h>


int main (int argc, void **argv)
{
    int arvattavaNumero;
    int yritysKerrat = 1;
    int arvattuNumero;
    time_t siemen;
    int i;
    char vastaus;

    do
    {

    time(&siemen);
    srand(siemen);

    arvattavaNumero = (rand() % 99) + 1;

    printf("\nTama on numeronarvauspeli\n");
    printf("Arvaa jokin luku valilta 1-100: ");
    scanf("%d", &arvattuNumero);

    while (arvattuNumero != arvattavaNumero)
    {
        if(arvattuNumero<arvattavaNumero)
        {
            printf("Arvasit vaarin. Numero on liian pieni.\n");
            printf("Arvaa uudestaan: ");
        }
        else if(arvattuNumero>arvattavaNumero)
        {
            printf("Arvasit vaarin. Numero on liian suuri.\n");
            printf("Arvaa uudestaan: ");
        }
        scanf("%d", &arvattuNumero);
        yritysKerrat++;
    }

    if( arvattuNumero == arvattavaNumero)
    {
            printf("Arvasit oikein!\n");
            printf("Arvasit %d kertaa", yritysKerrat);
            printf("\nOikea vastaus oli %d", arvattavaNumero);
            printf("\nHaluatko pelata uudelleen k/e? ");
            vastaus = getche();
    }
    }while (vastaus == 'k');

    return 0;
}
