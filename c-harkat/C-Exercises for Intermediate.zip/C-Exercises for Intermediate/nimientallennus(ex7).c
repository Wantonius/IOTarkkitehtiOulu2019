#include <stdio.h>

int main (int argc, void **argv)
{
    FILE *tiedosto;
    char nimet[64];
    int valinta = 0;
    char nimi[64];
    char puskuri[1];

    while(valinta!=3)
    {
        printf("Valitse, haluatko \n");
        printf("1.Tallentaa nimen tiedostoon \n");
        printf("2.Lukea kaikki nimet tiedostosta \n");
        printf("3.Lopeta \n");
        gets(puskuri);
        sscanf(puskuri, "%d", &valinta);

        if(valinta==1)
        {
            printf("Anna nimi: ");
            gets(nimi);
            tiedosto = fopen("nimet.txt", "a");
            fprintf (tiedosto, "%s\n", nimi);
            fclose(tiedosto);
        }

        else if (valinta==2)
        {
            tiedosto = fopen("nimet.txt", "r");

            if (tiedosto != NULL)
            {
                while (fscanf(tiedosto, "%s", nimet)!=EOF)
                {
                    //fgets(nimet, 64, tiedosto);
                    printf("%s\n", nimet);
                }
            }
            else
            {
                printf("tiedosto on tyhj�");
            }
            fclose(tiedosto);
        }
    }
    return 0;
}
