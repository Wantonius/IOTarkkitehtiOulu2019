/*
 ============================================================================
 Name        : Exercise_6.c
 Author      : Sari Prittinen
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void create_list();
void read_list();

int main(void) {

	int selection = 0;
	char list_name[20] = "";

	//while user selects 3
	while(selection != 3)
	{
		//menu
		printf("\nShopping List\n");

		printf("Do you want to\n");
		printf("1. Create a new shopping list\n");
		printf("2. Read an existing list\n");
		printf("3. Exit?\n");
		scanf("%d", &selection);

		//selection: new list
		if(selection == 1)
		{
			create_list();
		}
		//selection: existing list
		else if(selection == 2)
		{
			printf("Enter the name of the list to read:");
			scanf("%s", &list_name);
			read_list(list_name);
		}
	}
	return 0;
}

/**This function creates a new shopping list
 * Function asks items and prices from user
 * and saves them to a file
 */
void create_list()
{
	char list_name[20] = "";
	char item[20] = "";
	float price = 0;
	float total_price = 0;
	FILE *fptr;

	//asking the name of the list and opening a file for that name
	printf("Enter the name of shopping list: ");
	scanf("%s", &list_name);
	fptr = fopen(list_name, "w");

	if (fptr == NULL)
	{
		printf ("Cannot open file to write!\n");
		exit(-1);
	}
	else
	{
		printf("Enter the items and when ready enter \"ready\".\n");

		//asking items and prices until user enters "ready"
		while(strcmp(item, "ready") != 0)
		{
			printf("Item:");
			scanf("%s", &item);

			if(strcmp(item, "ready") != 0)
			{
				fprintf(fptr, "%s\t", item); //saving item to the file
				printf("Price:");
				scanf("%f", &price);
				total_price += price;
				fprintf(fptr, "%.2f\n", price); //saving price to the file
			}
		}
		fprintf(fptr, "Total price: %.2f\n", total_price); //saving total price to the file
		fclose (fptr); //closing file
		read_list(list_name); //display the list
	}
}

/**This function reads and displays a shopping list from a file
 * param: name of the list
 */
void read_list(char list[20])
{
	FILE *fptr;
	char line[1000];

	fptr = fopen(list, "r"); //opening the file
	if (fptr == NULL)
	{
		printf ("Cannot find the list \"%s\"!\n", list);
	}
	else
	{
		printf("\n");
		while(fgets(line, 1000, fptr) != 0) //going through the file
		{
			printf("%s", line); //printing data from file
		}
		printf("\n");
		fclose(fptr); //closing the file
	}

}
