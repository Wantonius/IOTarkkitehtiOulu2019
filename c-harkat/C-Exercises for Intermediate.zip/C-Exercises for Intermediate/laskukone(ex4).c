#include <stdio.h>

int main (int argc, char **argv)
{
	int luku1, luku2, tulos, valinta;

	printf("Minka laskutoimituksen haluat?\n");
	printf("1. Pluslasku\n2. Miinuslasku\n3. Kertolasku\n4. Jakolasku\n");
	scanf("%d", &valinta);

	
	printf("Anna luku: ");
	scanf("%d", &luku1);
	printf("Anna toinen luku: ");
	scanf("%d", &luku2);

	if(valinta==1)
	{
		tulos = luku1 + luku2;
	}
	else if (valinta==2)
	{
		tulos = luku1 - luku2;
	}
	else if (valinta==3)
	{
		tulos = luku1 * luku2;
	}
	else if (valinta==4)
	{
		tulos = luku1 / luku2;
	}

	printf("vastaus: %d\n", tulos);
	return 0;
}
