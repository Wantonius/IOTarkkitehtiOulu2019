#include <stdio.h>
#include <math.h>

int main (int argc, void **argv)
{
    float luku1, luku2;
    float tulos;

    printf("anna sivun pituus: ");
    scanf("%f", &luku1);
    printf("anna toisen sivun pituus: ");
    scanf("%f", &luku2);

    tulos = sqrt(pow(luku1,2)+pow(luku2,2));

    printf("hypotenuusan pituus on %.2f", tulos);

    return 0;

}
